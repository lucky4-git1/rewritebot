let o=null,b=null,u="",h=null,g=!1,w=null;function m(){g=!1,clearTimeout(w),o&&(o.remove(),o=null,b=null)}function A(){return document.fullscreenElement||document.body||document.documentElement}function T(t){var r;const n=document.activeElement;if(n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement&&/^(text|search|url|tel)$/i.test(n.type||"text")){const i=n.selectionStart??0,d=n.selectionEnd??0;if(d>i){const c=n.value.substring(i,d).trim();if(c.length>=2){const f=n.getBoundingClientRect();return{text:c,coords:{x:Math.min(window.innerWidth-130,Math.max(16,f.right-110)),y:Math.min(window.innerHeight-50,Math.max(16,f.bottom+8))},targetEl:n}}}}const e=window.getSelection(),s=e?e.toString().trim():"";if(s&&s.length>=2&&e&&e.rangeCount>0){const d=e.getRangeAt(0).getBoundingClientRect();if(d.width>0||d.height>0){let c=d.bottom+8;return c+45>window.innerHeight&&(c=Math.max(12,d.top-40)),{text:s,coords:{x:Math.min(window.innerWidth-130,Math.max(16,d.right+6)),y:Math.min(window.innerHeight-45,Math.max(12,c))},targetEl:((r=e.anchorNode)==null?void 0:r.parentElement)||null}}}return s&&s.length>=2&&t?{text:s,coords:{x:Math.min(window.innerWidth-130,Math.max(16,t.clientX+8)),y:Math.min(window.innerHeight-50,Math.max(16,t.clientY+8))},targetEl:t.target||null}:null}["mouseup","pointerup","keyup"].forEach(t=>{window.addEventListener(t,n=>{g||o&&n.composedPath&&n.composedPath().includes(o)||(clearTimeout(w),w=setTimeout(()=>{if(g)return;const e=T(n instanceof MouseEvent?n:void 0);e?(u=e.text,h=e.targetEl||null,B(e.coords.x,e.coords.y)):m()},50))})});window.addEventListener("pointerdown",t=>{g&&o&&((t.composedPath?t.composedPath():[]).includes(o)||m())},!0);window.addEventListener("keydown",t=>{if(t.altKey&&(t.key==="r"||t.key==="R"||t.code==="KeyR")){t.preventDefault(),t.stopPropagation();const e=T();if(e&&e.text)u=e.text,h=e.targetEl||null,y(e.coords);else{const s=document.activeElement;let r="";(s instanceof HTMLTextAreaElement||s instanceof HTMLInputElement)&&(r=s.value.trim(),h=s),u=r,y({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))})}}t.key==="Escape"&&m()},!0);chrome.runtime.onMessage.addListener(t=>{if(t.type==="REWRITE_TRIGGER"||t.type==="REWRITE_SHORTCUT_TRIGGER"){const n=T();n&&n.text?(u=n.text,h=n.targetEl||null,y(n.coords)):(t.text&&(u=t.text.trim()),y({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))}))}});function B(t,n){m(),o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",o.style.left=`${Math.max(12,Math.min(window.innerWidth-120,t))}px`,o.style.top=`${n}px`,A().appendChild(o),b=o.attachShadow({mode:"open"});const s=document.createElement("style");s.textContent=`
    .rb-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: linear-gradient(135deg, #670626 0%, #4a031a 100%);
      color: #ffffff;
      border-radius: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(103, 6, 38, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.25);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      user-select: none;
      animation: rbPillPop 0.15s ease-out;
    }
    @keyframes rbPillPop {
      0% { opacity: 0; transform: scale(0.85); }
      100% { opacity: 1; transform: scale(1); }
    }
    .rb-pill:hover {
      transform: translateY(-1px) scale(1.03);
      box-shadow: 0 6px 20px rgba(103, 6, 38, 0.5);
    }
    .rb-icon {
      font-size: 13px;
    }
  `;const r=document.createElement("div");r.className="rb-pill",r.innerHTML='<span class="rb-icon">✍️</span> <span>Rewrite</span>';const i=d=>{d.preventDefault(),d.stopPropagation()};r.addEventListener("mousedown",i),r.addEventListener("pointerdown",i),r.addEventListener("mouseup",i),r.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),clearTimeout(w),y({x:t,y:n})}),b.appendChild(s),b.appendChild(r)}function y(t){var L,P,k,H;g=!0,clearTimeout(w),!b||!o?(o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",A().appendChild(o),b=o.attachShadow({mode:"open"})):o.style.position="fixed";const e=Math.min(window.innerWidth-380-16,Math.max(16,t.x)),s=Math.min(window.innerHeight-360,Math.max(16,t.y));o.style.left=`${e}px`,o.style.top=`${s}px`,b.innerHTML="";const r=document.createElement("style");r.textContent=`
    .rb-card {
      width: 380px;
      background: #ffffff;
      color: #171314;
      border-radius: 12px;
      border: 1px solid #e5e7eb;
      box-shadow: 0 12px 36px rgba(0, 0, 0, 0.22), 0 2px 6px rgba(0, 0, 0, 0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: rbFadeIn 0.15s ease-out;
    }
    @keyframes rbFadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .rb-header {
      padding: 10px 14px;
      background: #fdfaf6;
      border-bottom: 1px solid #f1f3f5;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .rb-title {
      font-size: 13px;
      font-weight: 700;
      color: #670626;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .rb-close {
      cursor: pointer;
      color: #9ca3af;
      font-size: 16px;
      background: none;
      border: none;
      padding: 0;
      line-height: 1;
    }
    .rb-close:hover {
      color: #374151;
    }
    .rb-body {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .rb-modes {
      display: flex;
      gap: 4px;
      overflow-x: auto;
      padding-bottom: 2px;
    }
    .rb-mode-btn {
      padding: 4px 10px;
      border-radius: 14px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      color: #4b5563;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.15s ease;
    }
    .rb-mode-btn:hover {
      background: #f3f4f6;
    }
    .rb-mode-btn.active {
      background: #670626;
      color: #ffffff;
      border-color: #670626;
    }
    .rb-input-area {
      width: 100%;
      box-sizing: border-box;
      min-height: 55px;
      max-height: 90px;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-family: inherit;
      font-size: 12px;
      resize: vertical;
    }
    .rb-output-box {
      min-height: 75px;
      max-height: 160px;
      overflow-y: auto;
      padding: 10px;
      background: #fcfcfc;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.5;
      color: #1f2937;
      word-break: break-word;
    }
    .rb-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 4px;
    }
    .rb-btn-primary {
      padding: 6px 14px;
      background: #670626;
      color: #ffffff;
      border-radius: 6px;
      border: none;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s ease;
    }
    .rb-btn-primary:hover {
      background: #4a031a;
    }
    .rb-btn-secondary {
      padding: 6px 12px;
      background: #f3f4f6;
      color: #374151;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .rb-btn-secondary:hover {
      background: #e5e7eb;
    }
    .rb-spinner {
      color: #670626;
      font-style: italic;
      font-size: 12px;
    }
    .rb-error {
      color: #dc2626;
      font-size: 12px;
    }
  `;const i=document.createElement("div");i.className="rb-card rb-card-open";let d="standard",c="";const f=!!(u&&u.trim().length>0);i.innerHTML=`
    <div class="rb-header">
      <div class="rb-title">✍️ RewriteBot</div>
      <button class="rb-close" id="rb-btn-close">✕</button>
    </div>
    <div class="rb-body">
      ${f?"":'<textarea class="rb-input-area" id="rb-manual-input" placeholder="Type or paste text to rewrite..."></textarea>'}
      <div class="rb-modes">
        <button class="rb-mode-btn active" data-mode="standard">Standard</button>
        <button class="rb-mode-btn" data-mode="fluency">Fluency</button>
        <button class="rb-mode-btn" data-mode="academic">Academic</button>
        <button class="rb-mode-btn" data-mode="humanize">Humanize</button>
        <button class="rb-mode-btn" data-mode="shorten">Shorten</button>
      </div>
      <div class="rb-output-box" id="rb-output">
        <span class="rb-spinner">${f?"Restructuring with RewriteBot…":"Enter text above to rewrite"}</span>
      </div>
      <div class="rb-footer">
        <button class="rb-btn-secondary" id="rb-btn-copy">📋 Copy</button>
        <div style="display: flex; gap: 6px;">
          <button class="rb-btn-secondary" id="rb-btn-rerun">🔄 Re-run</button>
          <button class="rb-btn-primary" id="rb-btn-replace">⚡ Replace in Page</button>
        </div>
      </div>
    </div>
  `,b.appendChild(r),b.appendChild(i),(L=i.querySelector("#rb-btn-close"))==null||L.addEventListener("click",l=>{l.stopPropagation(),m()});const x=i.querySelector("#rb-manual-input");x==null||x.addEventListener("input",()=>{u=x.value});const R=i.querySelectorAll(".rb-mode-btn");R.forEach(l=>{l.addEventListener("click",a=>{a.stopPropagation(),R.forEach(v=>v.classList.remove("active")),l.classList.add("active"),d=l.dataset.mode||"standard",M()})}),(P=i.querySelector("#rb-btn-rerun"))==null||P.addEventListener("click",l=>{l.stopPropagation(),M()}),(k=i.querySelector("#rb-btn-copy"))==null||k.addEventListener("click",l=>{if(l.stopPropagation(),c){navigator.clipboard.writeText(c);const a=i.querySelector("#rb-btn-copy");a&&(a.textContent="✓ Copied!",setTimeout(()=>a.textContent="📋 Copy",1500))}}),(H=i.querySelector("#rb-btn-replace"))==null||H.addEventListener("click",l=>{l.stopPropagation(),c&&(W(u,c),m())});async function M(){var v,S,C;const l=x?x.value.trim():u.trim(),a=i.querySelector("#rb-output");if(!l){a&&(a.innerHTML='<span class="rb-spinner">Please select or enter text to rewrite</span>');return}a&&(a.innerHTML='<span class="rb-spinner">Restructuring with RewriteBot…</span>');try{if(!((v=chrome.runtime)!=null&&v.id)){a&&(a.innerHTML='<span class="rb-error">🔄 Extension updated. Please refresh this page (F5).</span>');return}chrome.runtime.sendMessage({type:"EXECUTE_PARAPHRASE",payload:{text:l,mode:d}},p=>{var z,I;if((z=chrome.runtime)!=null&&z.lastError){const E=chrome.runtime.lastError.message||"";if(E.includes("invalidated")||E.includes("context")){a&&(a.innerHTML='<span class="rb-error">🔄 Extension updated. Please refresh this page (F5).</span>');return}}if(p!=null&&p.success&&((I=p.data)!=null&&I.text))c=p.data.text,a&&(a.textContent=c);else if(a){const E=(p==null?void 0:p.error)||"Rewrite failed. Check RewriteBot server connection.";a.innerHTML=`<span class="rb-error">${E}</span>`}})}catch(p){a&&((S=p.message)!=null&&S.includes("invalidated")||!((C=chrome.runtime)!=null&&C.id)?a.innerHTML='<span class="rb-error">🔄 Extension updated. Please refresh this page (F5).</span>':a.innerHTML=`<span class="rb-error">${p.message||"Extension error"}</span>`)}}f&&M()}function W(t,n){const e=h||document.activeElement;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const r=e.selectionStart||0,i=e.selectionEnd||0,d=e.value;e.value=d.slice(0,r)+n+d.slice(i),e.setSelectionRange(r,r+n.length),e.dispatchEvent(new Event("input",{bubbles:!0}));return}const s=window.getSelection();if(s&&s.rangeCount>0){const r=s.getRangeAt(0);r.deleteContents(),r.insertNode(document.createTextNode(n))}}
