let o=null,c=null,u="",m=null;function h(){o&&(o.remove(),o=null,c=null)}function H(){return document.fullscreenElement||document.body||document.documentElement}function w(n){var i;const t=document.activeElement;if(t instanceof HTMLTextAreaElement||t instanceof HTMLInputElement&&/^(text|search|url|tel)$/i.test(t.type||"text")){const a=t.selectionStart??0,s=t.selectionEnd??0;if(s>a){const d=t.value.substring(a,s).trim();if(d.length>=2){const f=t.getBoundingClientRect();return{text:d,coords:{x:Math.min(window.innerWidth-130,Math.max(16,f.right-110)),y:Math.min(window.innerHeight-50,Math.max(16,f.bottom+8))},targetEl:t}}}}const e=window.getSelection(),r=e?e.toString().trim():"";if(r&&r.length>=2&&e&&e.rangeCount>0){const s=e.getRangeAt(0).getBoundingClientRect();if(s.width>0||s.height>0){let d=s.bottom+8;return d+45>window.innerHeight&&(d=Math.max(12,s.top-40)),{text:r,coords:{x:Math.min(window.innerWidth-130,Math.max(16,s.right+6)),y:Math.min(window.innerHeight-45,Math.max(12,d))},targetEl:((i=e.anchorNode)==null?void 0:i.parentElement)||null}}}return r&&r.length>=2&&n?{text:r,coords:{x:Math.min(window.innerWidth-130,Math.max(16,n.clientX+8)),y:Math.min(window.innerHeight-50,Math.max(16,n.clientY+8))},targetEl:n.target||null}:null}let S=null;["mouseup","pointerup","keyup"].forEach(n=>{window.addEventListener(n,t=>{o&&t.composedPath&&t.composedPath().includes(o)||(clearTimeout(S),S=setTimeout(()=>{if(c!=null&&c.querySelector(".rb-card-open"))return;const e=w(t instanceof MouseEvent?t:void 0);e?(u=e.text,m=e.targetEl||null,C(e.coords.x,e.coords.y)):h()},60))})});window.addEventListener("keydown",n=>{if(n.altKey&&(n.key==="r"||n.key==="R"||n.code==="KeyR")){n.preventDefault(),n.stopPropagation();const e=w();if(e&&e.text)u=e.text,m=e.targetEl||null,g(e.coords);else{const r=document.activeElement;let i="";(r instanceof HTMLTextAreaElement||r instanceof HTMLInputElement)&&(i=r.value.trim(),m=r),u=i,g({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))})}}n.key==="Escape"&&h()},!0);chrome.runtime.onMessage.addListener(n=>{if(n.type==="REWRITE_TRIGGER"||n.type==="REWRITE_SHORTCUT_TRIGGER"){const t=w();t&&t.text?(u=t.text,m=t.targetEl||null,g(t.coords)):(n.text&&(u=n.text.trim()),g({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))}))}});function C(n,t){h(),o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",o.style.left=`${Math.max(12,Math.min(window.innerWidth-120,n))}px`,o.style.top=`${t}px`,H().appendChild(o),c=o.attachShadow({mode:"open"});const r=document.createElement("style");r.textContent=`
    .rb-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: linear-gradient(135deg, #670626 0%, #4a031a 100%);
      color: #ffffff;
      border-radius: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(103, 6, 38, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.25);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      user-select: none;
      animation: rbPillPop 0.15s ease-out;
    }
    @keyframes rbPillPop {
      0% { opacity: 0; transform: scale(0.85); }
      100% { opacity: 1; transform: scale(1); }
    }
    .rb-pill:hover {
      transform: translateY(-1px) scale(1.03);
      box-shadow: 0 6px 20px rgba(103, 6, 38, 0.5);
    }
    .rb-icon {
      font-size: 13px;
    }
  `;const i=document.createElement("div");i.className="rb-pill",i.innerHTML='<span class="rb-icon">✍️</span> <span>Rewrite</span>',i.addEventListener("click",a=>{a.stopPropagation(),g({x:n,y:t})}),c.appendChild(r),c.appendChild(i)}function g(n){var E,M,T,R;!c||!o?(o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",H().appendChild(o),c=o.attachShadow({mode:"open"})):o.style.position="fixed";const e=Math.min(window.innerWidth-380-16,Math.max(16,n.x)),r=Math.min(window.innerHeight-360,Math.max(16,n.y));o.style.left=`${e}px`,o.style.top=`${r}px`,c.innerHTML="";const i=document.createElement("style");i.textContent=`
    .rb-card {
      width: 380px;
      background: #ffffff;
      color: #171314;
      border-radius: 12px;
      border: 1px solid #e5e7eb;
      box-shadow: 0 12px 36px rgba(0, 0, 0, 0.2), 0 2px 6px rgba(0, 0, 0, 0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: rbFadeIn 0.15s ease-out;
    }
    @keyframes rbFadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .rb-header {
      padding: 10px 14px;
      background: #fdfaf6;
      border-bottom: 1px solid #f1f3f5;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .rb-title {
      font-size: 13px;
      font-weight: 700;
      color: #670626;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .rb-close {
      cursor: pointer;
      color: #9ca3af;
      font-size: 16px;
      background: none;
      border: none;
      padding: 0;
      line-height: 1;
    }
    .rb-close:hover {
      color: #374151;
    }
    .rb-body {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .rb-modes {
      display: flex;
      gap: 4px;
      overflow-x: auto;
      padding-bottom: 2px;
    }
    .rb-mode-btn {
      padding: 4px 10px;
      border-radius: 14px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      color: #4b5563;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.15s ease;
    }
    .rb-mode-btn:hover {
      background: #f3f4f6;
    }
    .rb-mode-btn.active {
      background: #670626;
      color: #ffffff;
      border-color: #670626;
    }
    .rb-input-area {
      width: 100%;
      box-sizing: border-box;
      min-height: 55px;
      max-height: 90px;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-family: inherit;
      font-size: 12px;
      resize: vertical;
    }
    .rb-output-box {
      min-height: 75px;
      max-height: 160px;
      overflow-y: auto;
      padding: 10px;
      background: #fcfcfc;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.5;
      color: #1f2937;
      word-break: break-word;
    }
    .rb-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 4px;
    }
    .rb-btn-primary {
      padding: 6px 14px;
      background: #670626;
      color: #ffffff;
      border-radius: 6px;
      border: none;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s ease;
    }
    .rb-btn-primary:hover {
      background: #4a031a;
    }
    .rb-btn-secondary {
      padding: 6px 12px;
      background: #f3f4f6;
      color: #374151;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .rb-btn-secondary:hover {
      background: #e5e7eb;
    }
    .rb-spinner {
      color: #670626;
      font-style: italic;
      font-size: 12px;
    }
    .rb-error {
      color: #dc2626;
      font-size: 12px;
    }
  `;const a=document.createElement("div");a.className="rb-card rb-card-open";let s="standard",d="";const f=!!(u&&u.trim().length>0);a.innerHTML=`
    <div class="rb-header">
      <div class="rb-title">✍️ RewriteBot</div>
      <button class="rb-close" id="rb-btn-close">✕</button>
    </div>
    <div class="rb-body">
      ${f?"":'<textarea class="rb-input-area" id="rb-manual-input" placeholder="Type or paste text to rewrite..."></textarea>'}
      <div class="rb-modes">
        <button class="rb-mode-btn active" data-mode="standard">Standard</button>
        <button class="rb-mode-btn" data-mode="fluency">Fluency</button>
        <button class="rb-mode-btn" data-mode="academic">Academic</button>
        <button class="rb-mode-btn" data-mode="humanize">Humanize</button>
        <button class="rb-mode-btn" data-mode="shorten">Shorten</button>
      </div>
      <div class="rb-output-box" id="rb-output">
        <span class="rb-spinner">${f?"Restructuring with RewriteBot…":"Enter text above to rewrite"}</span>
      </div>
      <div class="rb-footer">
        <button class="rb-btn-secondary" id="rb-btn-copy">📋 Copy</button>
        <div style="display: flex; gap: 6px;">
          <button class="rb-btn-secondary" id="rb-btn-rerun">🔄 Re-run</button>
          <button class="rb-btn-primary" id="rb-btn-replace">⚡ Replace in Page</button>
        </div>
      </div>
    </div>
  `,c.appendChild(i),c.appendChild(a),(E=a.querySelector("#rb-btn-close"))==null||E.addEventListener("click",h);const x=a.querySelector("#rb-manual-input");x==null||x.addEventListener("input",()=>{u=x.value});const v=a.querySelectorAll(".rb-mode-btn");v.forEach(p=>{p.addEventListener("click",()=>{v.forEach(l=>l.classList.remove("active")),p.classList.add("active"),s=p.dataset.mode||"standard",y()})}),(M=a.querySelector("#rb-btn-rerun"))==null||M.addEventListener("click",()=>{y()}),(T=a.querySelector("#rb-btn-copy"))==null||T.addEventListener("click",()=>{if(d){navigator.clipboard.writeText(d);const p=a.querySelector("#rb-btn-copy");p&&(p.textContent="✓ Copied!",setTimeout(()=>p.textContent="📋 Copy",1500))}}),(R=a.querySelector("#rb-btn-replace"))==null||R.addEventListener("click",()=>{d&&(P(u,d),h())});async function y(){const p=x?x.value.trim():u.trim(),l=a.querySelector("#rb-output");if(!p){l&&(l.innerHTML='<span class="rb-spinner">Please select or enter text to rewrite</span>');return}l&&(l.innerHTML='<span class="rb-spinner">Restructuring with RewriteBot…</span>');try{chrome.runtime.sendMessage({type:"EXECUTE_PARAPHRASE",payload:{text:p,mode:s}},b=>{var k;if(b!=null&&b.success&&((k=b.data)!=null&&k.text))d=b.data.text,l&&(l.textContent=d);else if(l){const L=(b==null?void 0:b.error)||"Rewrite failed. Check RewriteBot server connection.";l.innerHTML=`<span class="rb-error">${L}</span>`}})}catch(b){l&&(l.innerHTML=`<span class="rb-error">${b.message||"Extension error"}</span>`)}}f&&y()}function P(n,t){const e=m||document.activeElement;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const i=e.selectionStart||0,a=e.selectionEnd||0,s=e.value;e.value=s.slice(0,i)+t+s.slice(a),e.setSelectionRange(i,i+t.length),e.dispatchEvent(new Event("input",{bubbles:!0}));return}const r=window.getSelection();if(r&&r.rangeCount>0){const i=r.getRangeAt(0);i.deleteContents(),i.insertNode(document.createTextNode(t))}}
