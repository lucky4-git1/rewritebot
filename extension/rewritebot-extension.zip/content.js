let t=null,d=null,b="",g=null;function l(){t&&(t.remove(),t=null,d=null)}document.addEventListener("mouseup",w);document.addEventListener("keyup",n=>{n.key==="Escape"&&l()});chrome.runtime.onMessage.addListener(n=>{if(n.type==="REWRITE_TRIGGER"||n.type==="REWRITE_SHORTCUT_TRIGGER"){const o=window.getSelection(),e=o?o.toString().trim():"";e&&(b=e,y(h()))}});function h(){const n=window.getSelection();if(n&&n.rangeCount>0){const o=n.getRangeAt(0).getBoundingClientRect();return{x:Math.max(16,o.left+window.scrollX),y:o.bottom+window.scrollY+8}}return{x:window.innerWidth/2,y:window.innerHeight/2}}function w(n){if(t&&n.composedPath().includes(t))return;const o=window.getSelection(),e=o?o.toString().trim():"";if(!e||e.length<3){t&&!(d!=null&&d.querySelector(".rb-card-open"))&&l();return}b=e,g=document.activeElement,v(n.pageX,n.pageY)}function v(n,o){l(),t=document.createElement("div"),t.id="rewritebot-extension-root",t.style.position="absolute",t.style.zIndex="2147483647",t.style.left=`${n+10}px`,t.style.top=`${o+10}px`,document.body.appendChild(t),d=t.attachShadow({mode:"open"});const e=document.createElement("style");e.textContent=`
    .rb-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      background: linear-gradient(135deg, #670626 0%, #4a031a 100%);
      color: #ffffff;
      border-radius: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 14px rgba(103, 6, 38, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.2);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      user-select: none;
    }
    .rb-pill:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 18px rgba(103, 6, 38, 0.45);
    }
    .rb-icon {
      font-size: 14px;
    }
  `;const s=document.createElement("div");s.className="rb-pill",s.innerHTML='<span class="rb-icon">✍️</span> <span>Rewrite</span>',s.addEventListener("click",i=>{i.stopPropagation(),y({x:n,y:o})}),d.appendChild(e),d.appendChild(s)}function y(n){var u,f,x;(!d||!t)&&(t=document.createElement("div"),t.id="rewritebot-extension-root",t.style.position="absolute",t.style.zIndex="2147483647",document.body.appendChild(t),d=t.attachShadow({mode:"open"})),t.style.left=`${Math.min(window.innerWidth-380,Math.max(16,n.x))}px`,t.style.top=`${n.y}px`,d.innerHTML="";const o=document.createElement("style");o.textContent=`
    .rb-card {
      width: 360px;
      background: #ffffff;
      color: #171314;
      border-radius: 12px;
      border: 1px solid #e5e7eb;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15), 0 1px 3px rgba(0, 0, 0, 0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: rbFadeIn 0.15s ease-out;
    }
    @keyframes rbFadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .rb-header {
      padding: 10px 14px;
      background: #fdfaf6;
      border-bottom: 1px solid #f1f3f5;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .rb-title {
      font-size: 13px;
      font-weight: 700;
      color: #670626;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .rb-close {
      cursor: pointer;
      color: #9ca3af;
      font-size: 16px;
      background: none;
      border: none;
      padding: 0;
    }
    .rb-body {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .rb-modes {
      display: flex;
      gap: 4px;
      overflow-x: auto;
      padding-bottom: 4px;
    }
    .rb-mode-btn {
      padding: 4px 10px;
      border-radius: 14px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      color: #4b5563;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
    }
    .rb-mode-btn.active {
      background: #670626;
      color: #ffffff;
      border-color: #670626;
    }
    .rb-output-box {
      min-height: 80px;
      max-height: 180px;
      overflow-y: auto;
      padding: 10px;
      background: #fcfcfc;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.5;
      color: #1f2937;
    }
    .rb-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 6px;
    }
    .rb-btn-primary {
      padding: 6px 14px;
      background: #670626;
      color: #ffffff;
      border-radius: 6px;
      border: none;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .rb-btn-secondary {
      padding: 6px 12px;
      background: #f3f4f6;
      color: #374151;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .rb-spinner {
      color: #670626;
      font-style: italic;
      font-size: 12px;
    }
  `;const e=document.createElement("div");e.className="rb-card rb-card-open";let s="standard",i="";e.innerHTML=`
    <div class="rb-header">
      <div class="rb-title">✍️ RewriteBot</div>
      <button class="rb-close" id="rb-btn-close">✕</button>
    </div>
    <div class="rb-body">
      <div class="rb-modes">
        <button class="rb-mode-btn active" data-mode="standard">Standard</button>
        <button class="rb-mode-btn" data-mode="academic">Academic</button>
        <button class="rb-mode-btn" data-mode="fluency">Fluency</button>
        <button class="rb-mode-btn" data-mode="humanize">Humanize</button>
        <button class="rb-mode-btn" data-mode="shorten">Shorten</button>
      </div>
      <div class="rb-output-box" id="rb-output">
        <span class="rb-spinner">Restructuring with RewriteBot…</span>
      </div>
      <div class="rb-footer">
        <button class="rb-btn-secondary" id="rb-btn-copy">📋 Copy</button>
        <button class="rb-btn-primary" id="rb-btn-replace">⚡ Replace in Page</button>
      </div>
    </div>
  `,d.appendChild(o),d.appendChild(e),(u=e.querySelector("#rb-btn-close"))==null||u.addEventListener("click",l);const p=e.querySelectorAll(".rb-mode-btn");p.forEach(r=>{r.addEventListener("click",()=>{p.forEach(a=>a.classList.remove("active")),r.classList.add("active"),s=r.dataset.mode||"standard",c()})}),(f=e.querySelector("#rb-btn-copy"))==null||f.addEventListener("click",()=>{if(i){navigator.clipboard.writeText(i);const r=e.querySelector("#rb-btn-copy");r&&(r.textContent="✓ Copied!",setTimeout(()=>r.textContent="📋 Copy",1500))}}),(x=e.querySelector("#rb-btn-replace"))==null||x.addEventListener("click",()=>{i&&(E(b,i),l())});async function c(){const r=e.querySelector("#rb-output");r&&(r.innerHTML='<span class="rb-spinner">Restructuring with RewriteBot…</span>');try{chrome.runtime.sendMessage({type:"EXECUTE_PARAPHRASE",payload:{text:b,mode:s}},a=>{var m;a!=null&&a.success&&((m=a.data)!=null&&m.text)?(i=a.data.text,r&&(r.textContent=i)):r&&(r.textContent=(a==null?void 0:a.error)||"Rewrite failed. Check RewriteBot connection.")})}catch(a){r&&(r.textContent=a.message||"Error communicating with extension")}}c()}function E(n,o){const e=g||document.activeElement;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const i=e.selectionStart||0,p=e.selectionEnd||0,c=e.value;e.value=c.slice(0,i)+o+c.slice(p),e.setSelectionRange(i,i+o.length),e.dispatchEvent(new Event("input",{bubbles:!0}));return}const s=window.getSelection();if(s&&s.rangeCount>0){const i=s.getRangeAt(0);i.deleteContents(),i.insertNode(document.createTextNode(o))}}
