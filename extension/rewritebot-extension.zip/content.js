let o=null,u=null,b="",h=null,g=!1,w=null;function m(){g=!1,clearTimeout(w),o&&(o.remove(),o=null,u=null)}function S(){return document.fullscreenElement||document.body||document.documentElement}function E(t){var r;const n=document.activeElement;if(n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement&&/^(text|search|url|tel)$/i.test(n.type||"text")){const i=n.selectionStart??0,s=n.selectionEnd??0;if(s>i){const c=n.value.substring(i,s).trim();if(c.length>=2){const f=n.getBoundingClientRect();return{text:c,coords:{x:Math.min(window.innerWidth-130,Math.max(16,f.right-110)),y:Math.min(window.innerHeight-50,Math.max(16,f.bottom+8))},targetEl:n}}}}const e=window.getSelection(),a=e?e.toString().trim():"";if(a&&a.length>=2&&e&&e.rangeCount>0){const s=e.getRangeAt(0).getBoundingClientRect();if(s.width>0||s.height>0){let c=s.bottom+8;return c+45>window.innerHeight&&(c=Math.max(12,s.top-40)),{text:a,coords:{x:Math.min(window.innerWidth-130,Math.max(16,s.right+6)),y:Math.min(window.innerHeight-45,Math.max(12,c))},targetEl:((r=e.anchorNode)==null?void 0:r.parentElement)||null}}}return a&&a.length>=2&&t?{text:a,coords:{x:Math.min(window.innerWidth-130,Math.max(16,t.clientX+8)),y:Math.min(window.innerHeight-50,Math.max(16,t.clientY+8))},targetEl:t.target||null}:null}["mouseup","pointerup","keyup"].forEach(t=>{window.addEventListener(t,n=>{g||o&&n.composedPath&&n.composedPath().includes(o)||(clearTimeout(w),w=setTimeout(()=>{if(g)return;const e=E(n instanceof MouseEvent?n:void 0);e?(b=e.text,h=e.targetEl||null,C(e.coords.x,e.coords.y)):m()},50))})});window.addEventListener("pointerdown",t=>{g&&o&&((t.composedPath?t.composedPath():[]).includes(o)||m())},!0);window.addEventListener("keydown",t=>{if(t.altKey&&(t.key==="r"||t.key==="R"||t.code==="KeyR")){t.preventDefault(),t.stopPropagation();const e=E();if(e&&e.text)b=e.text,h=e.targetEl||null,y(e.coords);else{const a=document.activeElement;let r="";(a instanceof HTMLTextAreaElement||a instanceof HTMLInputElement)&&(r=a.value.trim(),h=a),b=r,y({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))})}}t.key==="Escape"&&m()},!0);chrome.runtime.onMessage.addListener(t=>{if(t.type==="REWRITE_TRIGGER"||t.type==="REWRITE_SHORTCUT_TRIGGER"){const n=E();n&&n.text?(b=n.text,h=n.targetEl||null,y(n.coords)):(t.text&&(b=t.text.trim()),y({x:Math.max(20,Math.round((window.innerWidth-380)/2)),y:Math.max(60,Math.round(window.innerHeight*.15))}))}});function C(t,n){m(),o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",o.style.left=`${Math.max(12,Math.min(window.innerWidth-120,t))}px`,o.style.top=`${n}px`,S().appendChild(o),u=o.attachShadow({mode:"open"});const a=document.createElement("style");a.textContent=`
    .rb-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: linear-gradient(135deg, #670626 0%, #4a031a 100%);
      color: #ffffff;
      border-radius: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(103, 6, 38, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.25);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      user-select: none;
      animation: rbPillPop 0.15s ease-out;
    }
    @keyframes rbPillPop {
      0% { opacity: 0; transform: scale(0.85); }
      100% { opacity: 1; transform: scale(1); }
    }
    .rb-pill:hover {
      transform: translateY(-1px) scale(1.03);
      box-shadow: 0 6px 20px rgba(103, 6, 38, 0.5);
    }
    .rb-icon {
      font-size: 13px;
    }
  `;const r=document.createElement("div");r.className="rb-pill",r.innerHTML='<span class="rb-icon">✍️</span> <span>Rewrite</span>';const i=s=>{s.preventDefault(),s.stopPropagation()};r.addEventListener("mousedown",i),r.addEventListener("pointerdown",i),r.addEventListener("mouseup",i),r.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),clearTimeout(w),y({x:t,y:n})}),u.appendChild(a),u.appendChild(r)}function y(t){var T,R,k,L;g=!0,clearTimeout(w),!u||!o?(o=document.createElement("div"),o.id="rewritebot-extension-root",o.style.position="fixed",o.style.zIndex="2147483647",S().appendChild(o),u=o.attachShadow({mode:"open"})):o.style.position="fixed";const e=Math.min(window.innerWidth-380-16,Math.max(16,t.x)),a=Math.min(window.innerHeight-360,Math.max(16,t.y));o.style.left=`${e}px`,o.style.top=`${a}px`,u.innerHTML="";const r=document.createElement("style");r.textContent=`
    .rb-card {
      width: 380px;
      background: #ffffff;
      color: #171314;
      border-radius: 12px;
      border: 1px solid #e5e7eb;
      box-shadow: 0 12px 36px rgba(0, 0, 0, 0.22), 0 2px 6px rgba(0, 0, 0, 0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: rbFadeIn 0.15s ease-out;
    }
    @keyframes rbFadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .rb-header {
      padding: 10px 14px;
      background: #fdfaf6;
      border-bottom: 1px solid #f1f3f5;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .rb-title {
      font-size: 13px;
      font-weight: 700;
      color: #670626;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .rb-close {
      cursor: pointer;
      color: #9ca3af;
      font-size: 16px;
      background: none;
      border: none;
      padding: 0;
      line-height: 1;
    }
    .rb-close:hover {
      color: #374151;
    }
    .rb-body {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .rb-modes {
      display: flex;
      gap: 4px;
      overflow-x: auto;
      padding-bottom: 2px;
    }
    .rb-mode-btn {
      padding: 4px 10px;
      border-radius: 14px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      color: #4b5563;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.15s ease;
    }
    .rb-mode-btn:hover {
      background: #f3f4f6;
    }
    .rb-mode-btn.active {
      background: #670626;
      color: #ffffff;
      border-color: #670626;
    }
    .rb-input-area {
      width: 100%;
      box-sizing: border-box;
      min-height: 55px;
      max-height: 90px;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-family: inherit;
      font-size: 12px;
      resize: vertical;
    }
    .rb-output-box {
      min-height: 75px;
      max-height: 160px;
      overflow-y: auto;
      padding: 10px;
      background: #fcfcfc;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.5;
      color: #1f2937;
      word-break: break-word;
    }
    .rb-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 4px;
    }
    .rb-btn-primary {
      padding: 6px 14px;
      background: #670626;
      color: #ffffff;
      border-radius: 6px;
      border: none;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s ease;
    }
    .rb-btn-primary:hover {
      background: #4a031a;
    }
    .rb-btn-secondary {
      padding: 6px 12px;
      background: #f3f4f6;
      color: #374151;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .rb-btn-secondary:hover {
      background: #e5e7eb;
    }
    .rb-spinner {
      color: #670626;
      font-style: italic;
      font-size: 12px;
    }
    .rb-error {
      color: #dc2626;
      font-size: 12px;
    }
  `;const i=document.createElement("div");i.className="rb-card rb-card-open";let s="standard",c="";const f=!!(b&&b.trim().length>0);i.innerHTML=`
    <div class="rb-header">
      <div class="rb-title">✍️ RewriteBot</div>
      <button class="rb-close" id="rb-btn-close">✕</button>
    </div>
    <div class="rb-body">
      ${f?"":'<textarea class="rb-input-area" id="rb-manual-input" placeholder="Type or paste text to rewrite..."></textarea>'}
      <div class="rb-modes">
        <button class="rb-mode-btn active" data-mode="standard">Standard</button>
        <button class="rb-mode-btn" data-mode="fluency">Fluency</button>
        <button class="rb-mode-btn" data-mode="academic">Academic</button>
        <button class="rb-mode-btn" data-mode="humanize">Humanize</button>
        <button class="rb-mode-btn" data-mode="shorten">Shorten</button>
      </div>
      <div class="rb-output-box" id="rb-output">
        <span class="rb-spinner">${f?"Restructuring with RewriteBot…":"Enter text above to rewrite"}</span>
      </div>
      <div class="rb-footer">
        <button class="rb-btn-secondary" id="rb-btn-copy">📋 Copy</button>
        <div style="display: flex; gap: 6px;">
          <button class="rb-btn-secondary" id="rb-btn-rerun">🔄 Re-run</button>
          <button class="rb-btn-primary" id="rb-btn-replace">⚡ Replace in Page</button>
        </div>
      </div>
    </div>
  `,u.appendChild(r),u.appendChild(i),(T=i.querySelector("#rb-btn-close"))==null||T.addEventListener("click",l=>{l.stopPropagation(),m()});const x=i.querySelector("#rb-manual-input");x==null||x.addEventListener("input",()=>{b=x.value});const M=i.querySelectorAll(".rb-mode-btn");M.forEach(l=>{l.addEventListener("click",d=>{d.stopPropagation(),M.forEach(p=>p.classList.remove("active")),l.classList.add("active"),s=l.dataset.mode||"standard",v()})}),(R=i.querySelector("#rb-btn-rerun"))==null||R.addEventListener("click",l=>{l.stopPropagation(),v()}),(k=i.querySelector("#rb-btn-copy"))==null||k.addEventListener("click",l=>{if(l.stopPropagation(),c){navigator.clipboard.writeText(c);const d=i.querySelector("#rb-btn-copy");d&&(d.textContent="✓ Copied!",setTimeout(()=>d.textContent="📋 Copy",1500))}}),(L=i.querySelector("#rb-btn-replace"))==null||L.addEventListener("click",l=>{l.stopPropagation(),c&&(z(b,c),m())});async function v(){const l=x?x.value.trim():b.trim(),d=i.querySelector("#rb-output");if(!l){d&&(d.innerHTML='<span class="rb-spinner">Please select or enter text to rewrite</span>');return}d&&(d.innerHTML='<span class="rb-spinner">Restructuring with RewriteBot…</span>');try{chrome.runtime.sendMessage({type:"EXECUTE_PARAPHRASE",payload:{text:l,mode:s}},p=>{var P;if(p!=null&&p.success&&((P=p.data)!=null&&P.text))c=p.data.text,d&&(d.textContent=c);else if(d){const H=(p==null?void 0:p.error)||"Rewrite failed. Check RewriteBot server connection.";d.innerHTML=`<span class="rb-error">${H}</span>`}})}catch(p){d&&(d.innerHTML=`<span class="rb-error">${p.message||"Extension error"}</span>`)}}f&&v()}function z(t,n){const e=h||document.activeElement;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const r=e.selectionStart||0,i=e.selectionEnd||0,s=e.value;e.value=s.slice(0,r)+n+s.slice(i),e.setSelectionRange(r,r+n.length),e.dispatchEvent(new Event("input",{bubbles:!0}));return}const a=window.getSelection();if(a&&a.rangeCount>0){const r=a.getRangeAt(0);r.deleteContents(),r.insertNode(document.createTextNode(n))}}
